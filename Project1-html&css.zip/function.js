function numButton(buttonNumber) {
		console.log("button clicked " + buttonNumber);
		document.getElementById('display').value = parseFloat(document.getElementById('display').value + buttonNumber);
	}